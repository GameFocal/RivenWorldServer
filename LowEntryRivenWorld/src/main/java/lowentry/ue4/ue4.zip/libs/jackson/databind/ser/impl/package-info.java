/**
 * Contains implementation classes of serialization part of 
 * data binding.
 */
package lowentry.ue4.libs.jackson.databind.ser.impl;
