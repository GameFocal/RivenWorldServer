/**
 * Package that contains standard implementations for
 * {@link lowentry.ue4.libs.jackson.databind.jsontype.TypeResolverBuilder}
 * and
 * {@link lowentry.ue4.libs.jackson.databind.jsontype.TypeIdResolver}.
 */
package lowentry.ue4.libs.jackson.databind.jsontype.impl;
