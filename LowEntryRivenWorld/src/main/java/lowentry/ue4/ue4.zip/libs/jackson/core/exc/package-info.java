/**
 * Package for some of {@link lowentry.ue4.libs.jackson.core.JsonProcessingException}
 * subtypes contained by streaming API.
 */
package lowentry.ue4.libs.jackson.core.exc;
