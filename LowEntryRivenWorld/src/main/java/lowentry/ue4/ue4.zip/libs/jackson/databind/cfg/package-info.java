/**
Package that contains most of configuration-related classes;
exception being couple of most-commonly used configuration
things (like Feature enumerations) that are at the
main level (<code>lowentry.ue4.libs.jackson.databind</code>).
*/

package lowentry.ue4.libs.jackson.databind.cfg;
