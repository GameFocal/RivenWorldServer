/**
 * Classes needed for JSON schema support (currently just ability
 * to generate schemas using serialization part of data mapping)
 */
package lowentry.ue4.libs.jackson.databind.jsonschema;
