/**
 * Utility classes used by Jackson Core functionality.
 */
package lowentry.ue4.libs.jackson.core.util;
